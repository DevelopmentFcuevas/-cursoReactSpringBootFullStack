package com.zosh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoshSocialYoutubeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZoshSocialYoutubeApplication.class, args);
	}

}
